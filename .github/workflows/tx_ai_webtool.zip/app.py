from flask import Flask, render_template, request, jsonify
import requests
from xgboost import XGBClassifier
import numpy as np

app = Flask(__name__)

API_URL = "https://taixiu.laucua.net/api/luckydice/GetLuckyDice?limit=16"

history = []
labels = []

model = XGBClassifier()
is_trained = False

def fetch_data():
    try:
        res = requests.get(API_URL)
        if res.status_code == 200:
            data = res.json()
            return [{"id": x["id"], "ketqua": "T" if x["point"] >= 11 else "X"} for x in data]
    except:
        return []
    return []

def convert_to_features(seq):
    return [[1 if ch == "T" else 0 for ch in s] for s in seq]

def train_model():
    global is_trained
    if len(history) >= 10:
        X = convert_to_features(history)
        y = [1 if k == "T" else 0 for k in labels]
        model.fit(np.array(X), np.array(y))
        is_trained = True

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/predict", methods=["GET"])
def predict():
    global history, labels
    data = fetch_data()
    if not data or len(data) < 11:
        return jsonify({"error": "Không đủ dữ liệu"}), 400

    # update history
    history = []
    labels = []
    for i in range(len(data)-10):
        seq = "".join([d["ketqua"] for d in data[i:i+10]])
        history.append(seq)
        labels.append(data[i+10]["ketqua"])

    train_model()

    latest_seq = "".join([d["ketqua"] for d in data[:10]])
    x = convert_to_features([latest_seq])
    prediction = model.predict(np.array(x))[0]
    ket_qua = "TÀI" if prediction == 1 else "XỈU"
    return jsonify({
        "du_doan": ket_qua,
        "chuoi": latest_seq,
        "phien_sau": data[0]["id"] + 1
    })

if __name__ == "__main__":
    app.run(debug=True)
